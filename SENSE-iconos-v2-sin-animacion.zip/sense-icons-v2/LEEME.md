# SENSE v2 · 64 iconos estáticos

SVG y PNG transparentes de 24, 48 y 96 px en claro y oscuro. Se conservan los 28 iconos anteriores y se añaden 36. Ver preview/catalogo.png y UI-MAP.json. Los atlas PNG son de 8 × 8 celdas, cada una de 48 px. No mezclar con CSS de v1. Las fuentes vectoriales son icon-definitions.mjs y additional-icons.mjs. El prompt de rediseño y la revisión de capturas están incluidos. El paquete con animación añade el helper web, las animaciones y sus variantes estáticas.
